const CONFIG = {
  ADMIN_BOT_TOKEN: "7213789475:AAEmE6PldmI0tfVkM1oZ--Ef4HcpvBewIk8",
  USERS_API: "https://67c8964c0acf98d07087272b.mockapi.io/users",
  TRANSACTIONS_API: "https://67c8964c0acf98d07087272b.mockapi.io/transactions",
  ADMIN_CHAT_ID: "-4754251527"
}